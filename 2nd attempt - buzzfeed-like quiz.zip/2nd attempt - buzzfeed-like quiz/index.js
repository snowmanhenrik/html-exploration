
document.addEventListener('DOMContentLoaded', postData);

const data = document.location.search;
const params = new URLSearchParams(data);

const tplace = params.get('tplace');
const budget = params.get('budget');
const language = params.getAll('language');
const crowdedness = params.get('crowdedness');
const distance = params.get('distance');

// and&&, or||, not!, in 

let place;
if (tplace == "snowy" && budget == "average" && language[1] == "russian" && distance == ("veryfar") && crowdedness == "quiet") { // 1st required logic statement
    place = 'Sheregesh';
    image = 'images/1000_F_476495541_aGyL1imtgTdcnglB8J6cwRX8xkEV8f6O.jpg'
    description = 'Sherengesh is a popular ski resort in Siberia, located in Tashtagolsky District of Kemerovo Oblast, Russia. The snow depth can reach 3-4 meters in peak winter, so it is the perfect place for all kinds of snowsports and winter recreatioal activities'    

} else if (tplace == "snowy" && (budget == "rich" || budget == "posh") && language == "english" && distance == "far" && crowdedness == "bustling") { // 2nd required logic statement
    place = 'Breckenridge';
    image = 'images/MGQzijCEkgVzhCAR.jpg'
    description = 'Breckenridge is a Colorado town at the base of the Rocky Mountains’ Tenmile Range. It is known for its ski resort, year-round alpine activities and Gold Rush history. It is a bit expensive, but the slopes and accommodations there are GREAT!'

} else if (budget != "poor" && distance == "close") {
    place = 'the Great Smoky Mountains';
    image = 'images/Clifftops4-7-07.jpg'
    description = 'Ridge upon ridge of forest straddles the border between North Carolina and Tennessee in Great Smoky Mountains National Park. World renowned for its diversity of plant and animal life, the beauty of its ancient mountains, and the quality of its remnants of Southern Appalachian mountain culture, this is the most visited national park in America.'
    
} else if ((tplace == "woods" || tplace == "snowy") && budget == "rich" && language[1] == "german" && distance == "veryfar" && crowdedness == "quiet") { //3rd required logic statement
    place = 'Schwarzwald';
    image = 'images/deutschland-schwarzwald-panorama-1536x840.jpg'
    description = 'Also known as the Black Forest, Schwarzwald is a large forested mountain range in the state of Baden-Württemberg in southwest Germany, bounded by the Rhine Valley to the west and south and close to the borders with France and Switzerland. The alpine landscape will surely entertain all the tree and nature lovers out there!'

} else if (tplace == "beach" && (budget == "posh" || budget == "rich") && language[0] == "english" && distance == "intermediate" && crowdedness == "bustling") { //4th required logic statement
    place = "Bermuda"
    image = 'images/TimMLanthier-eced7b2434724a9a9bf3cc7733834c13.jpg'
    description = 'Bermuda is the place where you can enjoy pink-sand beaches and party boats, the smell of cedar and spice berries, the sound of gombey whistles, kiskadees, and clacks on a Crown and Anchor board.'

} else if (tplace == "city" && (budget == "rich") && (language[1] == "french" || language[0] == "french") && distance == "veryfar" && crowdedness == "bustling") { 
    place = "Paris"
    image = 'images/15770802_1004.webp'
    description = 'Paris is the capital city of France, and long has the stereotype of being a city of love and culture. Enjoy the Christmas markets there!'

} else if (tplace == "town" && (budget == "rich") && (language[1] == "french" || language[0] == "french") && distance == "veryfar" && (crowdedness == "bustling" || crowdedness == "quiet")) { 
    place = "Grasse"
    image = 'images/Grasse-Cannes-.png'
    description = 'Grasse is the world capital of perfume. Home to around 30 makers, tourists looking for a whiff of something good can enjoy multiple factory tours, along with some small town vibe and great archetecture.'

} else if (budget == "poor") { 
    place = "Charleston"
    image = 'images/Rainbow_Row_Panorama.jpg'
    description = 'We know Charleston is not the most exciting destination, but given your budget it would be a fair place to satisfy your wish for travelling in Christmas...'

} else {
    place = "Seattle"
    image = 'images/Seattle-at-Sunset-from-Kerry-Park.jpg'
    description = 'Seattle is a major city in the Pacific Northwest, and you can find just about anything few hours from the city. This includes workld-renowned ski resorts such as Mt. Baker and Crystal Mountain, and pristine nature such as the Snoqualmie Falls and Mount Rainier.'
    
}


// writing html code

function postData (){
    const container = document.getElementById('results');
    container.innerHTML = `<h1>You should visit ${place} during Christmas!</h1>
                           <img src="${image}"></img>
                           <h4>${description}</h4>`;
}






