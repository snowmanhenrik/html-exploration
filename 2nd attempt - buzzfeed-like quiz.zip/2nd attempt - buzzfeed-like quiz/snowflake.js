document.addEventListener("DOMContentLoaded", function() {


const maxSnowflakes = 100;

for (let i = 0; i < maxSnowflakes; i++) {
    createSnowflake();
}

function createSnowflake() {
    var snowflake = document.createElement('div');
    snowflake.classList.add('snowflake');
    snowflake.style.left = Math.random() * window.innerWidth + 'px';
    snowflake.style.animationDuration = (Math.random() * 5 + 2) + 's'; 
    snowflake.style.animationDelay = Math.random() * 5 + 's'; 
    document.body.appendChild(snowflake);

    snowflake.addEventListener('animationend', () => {
        snowflake.remove();
        createSnowflake(); 
    });
}

document.getElementById('showSanta').addEventListener('click', function() {
    var santaImg = document.getElementById('santa');
    santaImg.style.display = 'block';
    santaImg.classList.add('animate');

    setTimeout(() => {
        santaImg.classList.remove('animate');
    }, 8000);  
});

})